from flask import Flask, render_template, request

from user import user_bp
from admin import admin_bp  # Import admin blueprint
from datamodels import db
import os
import logging
from pyngrok import ngrok
logging.basicConfig(level=logging.DEBUG)
ngrok.set_auth_token('2j6yZx3KvVeSEOhGHG0bEjNdWB8_2ri6c36iDuZZxMJxxCD47')


app = Flask(__name__,template_folder='templates')

app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://action_detection_user:wUNih6QMixdRdLN2yWC8IKhdDn2eHHdD@dpg-crig5k68ii6s73f36h6g-a.oregon-postgres.render.com/action_detection"
app.config['SECRET_KEY'] = "1a2b3c4d5e6f7h"  # Replace with your secret key


# Initialize the database
db.init_app(app)

def add_cache_control(response):
    if request.endpoint in ['admin_bp.admin_dashboard', 'admin_bp.logout']:
        response.headers['Cache-Control'] = 'no-store'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    return response

# Register blueprints
app.register_blueprint(user_bp)
app.register_blueprint(admin_bp)

@app.route('/')
def index():
    return render_template('index.html')

with app.app_context():
    db.create_all()

print("Server starting at http://127.0.0.1:5000")
app.run(host='127.0.0.1', port=5000,debug=True)

